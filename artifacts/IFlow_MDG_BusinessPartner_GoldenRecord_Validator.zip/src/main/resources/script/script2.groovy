import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonOutput
import java.time.Instant

def Message processData(Message message) {
    def map = message.getProperties()
    def ex = map.get("CamelExceptionCaught")
    String errorMsg = ex ? ex.getMessage() : "Unhandled MDG Pipeline Error"

    message.setHeader("CamelHttpResponseCode", 500)
    message.setHeader("Content-Type", "application/json")

    def errorResponse = [
        error: "MDG_PIPELINE_EXECUTION_FAILED",
        timestamp: Instant.now().toString(),
        details: errorMsg
    ]
    message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(errorResponse)))
    return message
}