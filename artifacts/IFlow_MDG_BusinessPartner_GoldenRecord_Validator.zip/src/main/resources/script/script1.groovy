import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonOutput
import java.security.MessageDigest
import java.time.Instant

def Message processData(Message message) {
    def body = message.getBody(String)
    def jsonSlurper = new JsonSlurper()
    def payload = jsonSlurper.parseText(body)

    // 1. Ekstrakcija kljucnih polja za S/4HANA 2025 API_BUSINESS_PARTNER
    String bpName = (payload.BusinessPartnerFullName ?: "").trim()
    String taxNumber = (payload.TaxNumber1 ?: "").replaceAll("[^A-Za-z0-9]", "").toUpperCase()
    String iban = (payload.IBAN ?: "").replaceAll("\\s+", "").toUpperCase()
    String countryCode = (payload.Country ?: "").trim().toUpperCase()

    List<String> validationErrors = []

    // 2. Validacija obaveznih polja i ISO koda drzave
    if (!bpName || bpName.length() < 3) {
        validationErrors.add("INVALID_BP_NAME: BusinessPartnerFullName must contain at least 3 characters.")
    }
    if (!countryCode || countryCode.length() != 2) {
        validationErrors.add("INVALID_COUNTRY: ISO 3166-1 alpha-2 country code is required.")
    }

    // 3. Mod-97 IBAN kontrolni zbir (ISO 13616)
    if (!isValidIban(iban)) {
        validationErrors.add("INVALID_IBAN_CHECKSUM: Failed ISO 13616 Mod-97 verification for IBAN [${iban}].")
    }

    // 4. Real-Time OFAC / EU Sanctions Screening (Simulacija watchliste)
    List<String> sanctionedEntities = ["SHADOW HOLDINGS LTD", "NEXUS EMBARGO CORP", "VORTEX SANCTIONED GMBH"]
    String normalizedName = bpName.toUpperCase().replaceAll("[^A-Z0-9 ]", "")
    boolean isSanctioned = sanctionedEntities.any { sanctioned ->
        calculateSimilarity(normalizedName, sanctioned) >= 0.85d
    }
    if (isSanctioned) {
        validationErrors.add("COMPLIANCE_SANCTIONS_HIT: Entity matched OFAC/EU consolidated sanctions watchlist.")
    }

    // 5. Generisanje SHA-256 Golden Record Fingerprint-a za deduplikaciju
    String rawFingerprint = "${normalizedName}|${taxNumber}|${countryCode}"
    String goldenRecordHash = MessageDigest.getInstance("SHA-256")
        .digest(rawFingerprint.getBytes("UTF-8"))
        .encodeHex()
        .toString()

    // 6. Odluka za Router Gateway
    if (!validationErrors.isEmpty()) {
        message.setHeader("X-MDG-Gate-Status", "BLOCKED")
        message.setHeader("X-MDG-Golden-Hash", goldenRecordHash)
        def quarantineReport = [
            status: "QUARANTINED_FOR_MDG_STEWARDSHIP",
            timestamp: Instant.now().toString(),
            goldenRecordSha256: goldenRecordHash,
            businessPartnerName: bpName,
            violations: validationErrors
        ]
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(quarantineReport)))
    } else {
        message.setHeader("X-MDG-Gate-Status", "APPROVED")
        message.setHeader("X-MDG-Golden-Hash", goldenRecordHash)
        def s4CleanPayload = [
            "@odata.context": "\$metadata#A_BusinessPartner/\$entity",
            BusinessPartnerCategory: "2",
            BusinessPartnerFullName: bpName,
            BusinessPartnerGrouping: "BP02",
            GoldenRecordFingerprint: goldenRecordHash,
            to_BusinessPartnerTax: [
                [BPTaxType: "${countryCode}0", BPTaxNumber: taxNumber]
            ],
            to_BusinessPartnerBank: [
                [BankCountryKey: countryCode, IBAN: iban]
            ],
            ComplianceVerification: [
                SanctionsCheck: "PASSED",
                IbanMod97Check: "PASSED",
                VerifiedAt: Instant.now().toString()
            ]
        ]
        message.setBody(JsonOutput.prettyPrint(JsonOutput.toJson(s4CleanPayload)))
    }

    return message
}

private boolean isValidIban(String iban) {
    if (!iban || iban.length() < 15 || iban.length() > 34) return false
    String rearranged = iban.substring(4) + iban.substring(0, 4)
    StringBuilder numericIban = new StringBuilder()
    for (char ch : rearranged.toCharArray()) {
        if (Character.isDigit(ch)) {
            numericIban.append(ch)
        } else if (Character.isLetter(ch)) {
            numericIban.append(Character.getNumericValue(ch))
        } else {
            return false
        }
    }
    BigInteger ibanNumber = new BigInteger(numericIban.toString())
    return ibanNumber.mod(BigInteger.valueOf(97)).intValue() == 1
}

private double calculateSimilarity(String s1, String s2) {
    if (s1 == s2) return 1.0d
    int maxLen = Math.max(s1.length(), s2.length())
    if (maxLen == 0) return 1.0d
    int matches = 0
    int minLen = Math.min(s1.length(), s2.length())
    for (int i = 0; i < minLen; i++) {
        if (s1.charAt(i) == s2.charAt(i)) matches++
    }
    return (double) matches / (double) maxLen
}